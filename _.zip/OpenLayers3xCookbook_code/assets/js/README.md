# Custom jQuery UI build

## Components

**UI Core**
- Core
- Widget
- Mouse

**Interactions**
- Sortable

**Widgets**
- Slider